/*
 CSC 281 - Project #4
 modifier: Josh Sarath
 filename: project 4
 date last modified: 10/6/13

 */

#include <iostream>
#include "elevator.h"
using namespace std;


int main()
{
    int o,t; //intialize values for comparing location
	Elevator otis(10); //establishes instance of class
	Elevator toHeaven(7); //establishes instance of class
	otis.request(5); //request to floor
	otis.request(15);//request to floor
	otis.request(8);//request to floor
	toHeaven.request(6);//request to floor
	toHeaven.request(2);//request to floor
	o = otis.giveLocation(); //return location
	t = toHeaven.giveLocation();//return location
	if (o == t) //test whether on same floor
		cout<< "The elevators are on the same floor"; //reports they are
	else //not on same floor
		cout<<"The elevators are not on the same floor"; //reports they are not
	otis.request(2);//request to floor
	toHeaven.request(2);//request to floor
	o = otis.giveLocation();//return location
	t = toHeaven.giveLocation();//return location
	if (o == t)//test whether on same floor
		cout<< "The elevators are on the same floor";//reports they are
	else//not on same floor
		cout<<"The elevators are not on the same floor";//reports they are not
	return 0;

}