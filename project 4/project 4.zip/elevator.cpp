/*
 CSC 281 - Project #4
 modifier: Josh Sarath
 filename:
 date last modified: 10/3/13
 action:
 input:
 output:
 */

#include <math.h>
#include "Elevator.h"
//------------- Define member functions for class Triangle -------
//Constructor function with initialization:
Elevator::Elevator(int floors)
{
    floors = floors; // user choosen value of numebr of floors in building
    location = 1; //default floor for newly constructed elevator class
}

//request function
int Elevator::request(int floorTo)
/*
 action: requests elevator goes to a floor floorTo
 input:
 output:changes location of elevator
 */
{
	a = floorTo; // receives value from parameter
	b = location; // receives parameter from protected values
	if (a >floors)
		cout << "Not a valid floor"; // if users tries to go to a floor above building limit
		return 0; //ends function
	if (a>b) // for elevator going up
		cout << "Starting at floor "<< b << "\n";
		for (int a-b; a>b, b++) // for loop to 
			(cout << "Going up-- now at floor "<< b<<"\n"; //prints moving from original floor
			location = b // changes location as the elevator moves
		cout << "Stopping at floor " << a <<"\n"; //prints stopping at the new floor
	if (a<b) //elevator going down
		cout << "Starting at floor "<< b << "\n";
		for (int a-b; a<b, b--) // for loop to 
			(cout << "Going down-- now at floor "<< b<<"\n"; //prints moving from original floor
			location = b // changes location as the elevator moves
		cout << "Stopping at floor " << a <<"\n"; //prints stopping at the new floor
	location = floorTo; // elevator location changed to now be at the new floor
    return 0;    
}
//give location function
int Elevator::giveLocation()
/*
 action: returns location
 input:no input
 output:returns location
 */
{
    return location; // accesses location value of the class
}
